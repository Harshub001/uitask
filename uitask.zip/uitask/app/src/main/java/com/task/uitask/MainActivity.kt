package com.task.uitask

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {
    lateinit var zipcode: EditText
    lateinit var btncurrloc: Button
   lateinit var zipcoderight: TextView
    lateinit var skipfornow: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.location)
        //zipcodeleft = findViewById(R.id.zipcodeleft)
        zipcode= findViewById(R.id.zipcode)
        zipcoderight= findViewById(R.id.zipcoderight)
        btncurrloc= findViewById(R.id.btncurrentloc)
        skipfornow= findViewById(R.id.skipfornow)
    }
}